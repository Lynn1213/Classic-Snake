package com.example.snakegame

import android.app.Application
import com.example.snakegame.utils.LanguageManager

class SnakeGameApplication : Application() {

    companion object {
        private var instance: SnakeGameApplication? = null

        fun getAppContext(): android.content.Context {
            return instance!!.applicationContext
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    // 添加 updateLanguage 方法
    fun updateLanguage(language: String) {
        LanguageManager.setLanguage(this, language)
    }
}