package com.example.snakegame.model

import android.util.Log

class GameModel {
    private val snake = Snake()
    private var currentDifficulty: Difficulty = Difficulty.NORMAL

    companion object {
        private const val TAG = "GameModel"
    }

    fun setDifficulty(difficulty: Difficulty) {
        currentDifficulty = difficulty
        snake.setDifficulty(difficulty)
        Log.d(TAG, "游戏模型设置难度: ${difficulty.getDisplayName()}")
    }

    fun startNewGame() {
        Log.d(TAG, "开始新游戏，难度: ${currentDifficulty.getDisplayName()}")
        snake.initialize()
    }

    fun updateGame() {
        snake.update()
    }

    fun setDirection(direction: Direction) {
        snake.setDirection(direction)
    }

    fun getGameState(): GameState {
        return snake.gameState
    }

    fun isGameRunning(): Boolean {
        return snake.isGameRunning()
    }

    fun getCurrentScore(): Int {
        return snake.getCurrentScore()
    }

    fun getCurrentDifficulty(): Difficulty {
        return currentDifficulty
    }
}