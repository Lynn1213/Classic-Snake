package com.example.snakegame.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.snakegame.R
import com.example.snakegame.model.GameRecord

class ScoreHistoryAdapter(
    private var records: List<GameRecord> = emptyList(),
    private val isChinese: Boolean = false
) : RecyclerView.Adapter<ScoreHistoryAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val rankText: TextView = itemView.findViewById(R.id.rankText)
        val playerNameText: TextView = itemView.findViewById(R.id.playerNameText)
        val scoreText: TextView = itemView.findViewById(R.id.scoreText)
        val difficultyText: TextView = itemView.findViewById(R.id.difficultyText)
        val dateText: TextView = itemView.findViewById(R.id.dateText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_score_history, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val record = records[position]

        holder.rankText.text = "${position + 1}."
        holder.playerNameText.text = record.playerName
        holder.scoreText.text = record.score.toString()
        holder.difficultyText.text = record.getDifficultyName(isChinese)
        holder.dateText.text = record.getFormattedDate()

        // 高亮前三名
        when (position) {
            0 -> holder.itemView.setBackgroundResource(R.color.gold)
            1 -> holder.itemView.setBackgroundResource(R.color.silver)
            2 -> holder.itemView.setBackgroundResource(R.color.bronze)
            else -> holder.itemView.setBackgroundResource(android.R.color.transparent)
        }
    }

    override fun getItemCount(): Int = records.size

    fun updateData(newRecords: List<GameRecord>) {
        records = newRecords.sortedDescending()
        notifyDataSetChanged()
    }
}