package com.example.snakegame.utils

import android.content.Context
import android.content.SharedPreferences
import com.example.snakegame.model.Difficulty

object GameDifficultyManager {
    private const val PREF_NAME = "game_difficulty_prefs"
    private const val KEY_DIFFICULTY = "selected_difficulty"

    fun saveDifficulty(context: Context, difficulty: Difficulty) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putInt(KEY_DIFFICULTY, difficulty.id).apply()
    }

    fun getDifficulty(context: Context): Difficulty {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val difficultyId = prefs.getInt(KEY_DIFFICULTY, Difficulty.NORMAL.id)
        return Difficulty.fromId(difficultyId)
    }
}