package com.example.snakegame.model

import java.util.Date
import java.text.SimpleDateFormat
import java.util.Locale

data class GameRecord(
    val id: String = "${System.currentTimeMillis()}_${(0..1000).random()}",
    val playerName: String,
    val score: Int,
    val difficulty: Difficulty,
    val date: Date = Date(),
    val gameDuration: Long = 0 // 游戏时长（秒）
) : Comparable<GameRecord> {
    override fun compareTo(other: GameRecord): Int {
        // 按分数降序排序，分数相同按时间降序
        return if (score != other.score) {
            other.score.compareTo(score)
        } else {
            other.date.compareTo(date)
        }
    }

    fun getFormattedDate(locale: Locale = Locale.getDefault()): String {
        val pattern = if (locale.language == "zh") "yyyy-MM-dd HH:mm" else "MM/dd/yyyy HH:mm"
        return SimpleDateFormat(pattern, locale).format(date)
    }

    fun getDifficultyName(isChinese: Boolean): String {
        return difficulty.getDisplayName(isChinese)
    }
}