package com.example.snakegame.controller

import android.os.Handler
import android.os.Looper
import android.util.Log
import com.example.snakegame.model.Difficulty
import com.example.snakegame.model.Direction
import com.example.snakegame.model.GameModel
import com.example.snakegame.view.GameCallback
import com.example.snakegame.view.SnakeGameView

class GameController {
    private val gameModel = GameModel()
    private var gameView: SnakeGameView? = null
    private var gameCallback: GameCallback? = null

    private val gameHandler = Handler(Looper.getMainLooper())
    private var gameUpdateInterval = 200L // 默认普通难度速度
    private var isRunning = false

    companion object {
        private const val TAG = "GameController"
    }

    private val gameRunnable = object : Runnable {
        override fun run() {
            if (isRunning) {
                updateGame()
                gameHandler.postDelayed(this, gameUpdateInterval)
            }
        }
    }

    fun setDifficulty(difficulty: Difficulty) {
        Log.d(TAG, "GameController设置难度: ${difficulty.getDisplayName()}, 速度: ${difficulty.speed}ms, 基础得分: ${difficulty.baseScore}")

        // 1. 先设置游戏模型难度
        gameModel.setDifficulty(difficulty)

        // 2. 更新游戏循环间隔
        gameUpdateInterval = difficulty.speed

        // 3. 停止并重新启动游戏循环
        if (isRunning) {
            gameHandler.removeCallbacks(gameRunnable)
            gameHandler.postDelayed(gameRunnable, gameUpdateInterval)
        }
    }

    fun setView(view: SnakeGameView) {
        this.gameView = view
        this.gameView?.gameCallback = object : GameCallback {
            override fun onScoreUpdated(score: Int) {
                gameCallback?.onScoreUpdated(score)
            }

            override fun onGameOver(score: Int) {
                gameCallback?.onGameOver(score)
            }

            override fun onDirectionChanged(direction: Direction) {
                setDirection(direction)
            }

            override fun onGameRestart() {
                restartGame()
            }
        }
    }

    fun setCallback(callback: GameCallback) {
        this.gameCallback = callback
    }

    fun startGame() {
        Log.d(TAG, "开始游戏，难度速度: ${gameUpdateInterval}ms")
        isRunning = true
        gameModel.startNewGame()
        gameHandler.post(gameRunnable)
        updateView()
        Log.d(TAG, "游戏循环已启动")
    }

    fun stopGame() {
        Log.d(TAG, "停止游戏")
        isRunning = false
        gameHandler.removeCallbacks(gameRunnable)
    }

    fun restartGame() {
        Log.d(TAG, "重新开始游戏")
        stopGame()
        gameModel.startNewGame()
        startGame()
        gameCallback?.onScoreUpdated(0)
    }

    fun setDirection(direction: Direction) {
        gameModel.setDirection(direction)
    }

    private fun updateGame() {
        if (!isRunning) return

        try {
            gameModel.updateGame()
            updateView()

            val gameState = gameModel.getGameState()
            gameCallback?.onScoreUpdated(gameState.score)

            if (!gameModel.isGameRunning()) {
                // 传递最终分数
                gameCallback?.onGameOver(gameState.score)
                stopGame()
            }
        } catch (e: Exception) {
            Log.e(TAG, "更新游戏时发生错误", e)
            stopGame()
        }
    }

    private fun updateView() {
        try {
            val gameState = gameModel.getGameState()
            gameView?.updateGameState(gameState)
        } catch (e: Exception) {
            Log.e(TAG, "更新视图时发生错误", e)
        }
    }

    fun isGameRunning(): Boolean {
        return isRunning && gameModel.isGameRunning()
    }

    fun getCurrentScore(): Int {
        return gameModel.getCurrentScore()
    }

    fun getCurrentDifficulty(): Difficulty {
        return gameModel.getCurrentDifficulty()
    }
}