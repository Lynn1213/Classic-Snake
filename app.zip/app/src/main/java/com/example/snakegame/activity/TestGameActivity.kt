package com.example.snakegame.activity

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.snakegame.R
import com.example.snakegame.databinding.ActivityGameBinding

class TestGameActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGameBinding
    private lateinit var scoreTextView: TextView
    private lateinit var gameStatusTextView: TextView
    private lateinit var restartButton: Button
    private lateinit var menuButton: Button

    companion object {
        private const val TAG = "TestGameActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Log.d(TAG, "=== 开始测试 GameActivity ===")

        try {
            // 1. 测试布局加载
            Log.d(TAG, "步骤1: 尝试加载布局")
            binding = ActivityGameBinding.inflate(layoutInflater)
            setContentView(binding.root)
            Log.d(TAG, "✓ 布局加载成功")

            // 2. 测试视图绑定
            Log.d(TAG, "步骤2: 尝试绑定视图")
            initViews()
            Log.d(TAG, "✓ 视图绑定成功")

            // 3. 测试资源加载
            Log.d(TAG, "步骤3: 尝试加载资源")
            updateUITexts()
            Log.d(TAG, "✓ 资源加载成功")

            // 4. 测试点击监听器
            Log.d(TAG, "步骤4: 设置点击监听器")
            setupClickListeners()
            Log.d(TAG, "✓ 点击监听器设置成功")

            Log.d(TAG, "=== GameActivity 测试完成 ===")

        } catch (e: Exception) {
            Log.e(TAG, "!!! 测试失败 !!!", e)
            throw e
        }
    }

    private fun initViews() {
        scoreTextView = binding.scoreTextView
        gameStatusTextView = binding.gameStatusTextView
        restartButton = binding.restartButton
        menuButton = binding.menuButton

        // 检查每个视图是否成功绑定
        checkView(scoreTextView, "scoreTextView")
        checkView(gameStatusTextView, "gameStatusTextView")
        checkView(restartButton, "restartButton")
        checkView(menuButton, "menuButton")
    }

    private fun checkView(view: Any?, viewName: String) {
        if (view == null) {
            throw NullPointerException("视图 $viewName 绑定失败")
        }
        Log.d(TAG, "✓ $viewName 绑定成功")
    }

    private fun updateUITexts() {
        // 测试字符串资源
        val restartText = getString(R.string.restart)
        val menuText = getString(R.string.menu)
        val scoreText = getString(R.string.score_0)
        val gameStartedText = getString(R.string.game_started)

        restartButton.text = restartText
        menuButton.text = menuText
        scoreTextView.text = scoreText
        gameStatusTextView.text = gameStartedText

        Log.d(TAG, "✓ 字符串资源加载: restart='$restartText', menu='$menuText'")
    }

    private fun setupClickListeners() {
        restartButton.setOnClickListener {
            Log.d(TAG, "点击了重新开始按钮")
        }

        menuButton.setOnClickListener {
            Log.d(TAG, "点击了菜单按钮，返回主菜单")
            finish()
        }
    }
}