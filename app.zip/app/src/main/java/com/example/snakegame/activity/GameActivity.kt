package com.example.snakegame.activity

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.snakegame.R
import com.example.snakegame.controller.GameController
import com.example.snakegame.databinding.ActivityGameBinding
import com.example.snakegame.model.Difficulty
import com.example.snakegame.model.Direction
import com.example.snakegame.model.GameRecord
import com.example.snakegame.utils.GameDifficultyManager
import com.example.snakegame.utils.LanguageManager
import com.example.snakegame.utils.ScoreManager
import com.example.snakegame.view.GameCallback
import com.example.snakegame.view.GameOverDialog
import java.util.Date

class GameActivity : AppCompatActivity(), GameCallback {

    private lateinit var binding: ActivityGameBinding
    private lateinit var gameController: GameController
    private lateinit var scoreTextView: TextView
    private lateinit var gameStatusTextView: TextView
    private lateinit var difficultyTextView: TextView
    private lateinit var restartButton: Button
    private lateinit var menuButton: Button
    private lateinit var upButton: Button
    private lateinit var downButton: Button
    private lateinit var leftButton: Button
    private lateinit var rightButton: Button

    private var gameOverDialog: GameOverDialog? = null
    private val uiHandler = Handler(Looper.getMainLooper())
    private var isGameOver = false
    private var gameStartTime: Long = 0
    private var currentDifficulty: Difficulty = Difficulty.NORMAL

    // 修正lazy初始化
    private val scoreManager: ScoreManager by lazy { ScoreManager.getInstance(this) }

    companion object {
        private const val TAG = "GameActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Log.d(TAG, "=== GameActivity 开始启动 ===")

        try {
            binding = ActivityGameBinding.inflate(layoutInflater)
            setContentView(binding.root)

            initViews()
            setupGameController()
            setupClickListeners()

            // 延迟启动游戏，确保所有视图已初始化
            uiHandler.postDelayed({
                startGame()
            }, 1000)

            Log.d(TAG, "=== GameActivity 启动完成 ===")

        } catch (e: Exception) {
            Log.e(TAG, "!!! GameActivity 启动失败 !!!", e)
        }
    }

    private fun initViews() {
        scoreTextView = binding.scoreTextView
        gameStatusTextView = binding.gameStatusTextView
        difficultyTextView = binding.difficultyTextView
        restartButton = binding.restartButton
        menuButton = binding.menuButton
        upButton = binding.upButton
        downButton = binding.downButton
        leftButton = binding.leftButton
        rightButton = binding.rightButton

        updateUIWithCurrentLanguage()
    }

    private fun updateUIWithCurrentLanguage() {
        val language = LanguageManager.getLanguage(this)
        val isChinese = language == "zh"

        restartButton.text = if (isChinese) "重新开始" else "Restart"
        menuButton.text = if (isChinese) "返回菜单" else "Menu"
        scoreTextView.text = if (isChinese) "得分: 0" else "Score: 0"
        gameStatusTextView.text = if (isChinese) "游戏开始" else "Game Started"

        // 更新难度显示
        currentDifficulty = GameDifficultyManager.getDifficulty(this)
        val difficultyName = currentDifficulty.getDisplayName(isChinese)
        val scorePerFood = currentDifficulty.baseScore
        difficultyTextView.text = if (isChinese) {
            "难度: $difficultyName (每个食物: ${scorePerFood}分)"
        } else {
            "Difficulty: $difficultyName (${scorePerFood}pts/food)"
        }
    }

    private fun setupGameController() {
        Log.d(TAG, "设置游戏控制器")
        gameController = GameController()

        // 先设置难度，再设置视图和回调
        currentDifficulty = GameDifficultyManager.getDifficulty(this)
        Log.d(TAG, "从GameDifficultyManager获取难度: ${currentDifficulty.getDisplayName()}")
        gameController.setDifficulty(currentDifficulty)

        // 再设置视图和回调
        gameController.setView(binding.snakeGameView)
        gameController.setCallback(this)

        Log.d(TAG, "游戏控制器设置完成")
    }

    private fun setupClickListeners() {
        restartButton.setOnClickListener {
            restartGame()
        }

        menuButton.setOnClickListener {
            finish()
        }

        upButton.setOnClickListener {
            if (!isGameOver) gameController.setDirection(Direction.UP)
        }

        downButton.setOnClickListener {
            if (!isGameOver) gameController.setDirection(Direction.DOWN)
        }

        leftButton.setOnClickListener {
            if (!isGameOver) gameController.setDirection(Direction.LEFT)
        }

        rightButton.setOnClickListener {
            if (!isGameOver) gameController.setDirection(Direction.RIGHT)
        }
    }

    private fun startGame() {
        Log.d(TAG, "开始游戏逻辑")
        isGameOver = false
        gameStartTime = System.currentTimeMillis()
        hideGameOverDialog()

        // 再次确认难度设置
        currentDifficulty = GameDifficultyManager.getDifficulty(this)
        gameController.setDifficulty(currentDifficulty)

        gameController.startGame()

        val isChinese = LanguageManager.getLanguage(this) == "zh"
        gameStatusTextView.text = if (isChinese) "游戏进行中..." else "Game in progress..."
        Log.d(TAG, "游戏已启动，难度: ${currentDifficulty.getDisplayName()}")
    }

    private fun restartGame() {
        Log.d(TAG, "重新开始游戏")
        isGameOver = false
        gameStartTime = System.currentTimeMillis()
        hideGameOverDialog()
        gameController.restartGame()

        val isChinese = LanguageManager.getLanguage(this) == "zh"
        gameStatusTextView.text = if (isChinese) "游戏进行中..." else "Game in progress..."
        scoreTextView.text = if (isChinese) "得分: 0" else "Score: 0"
    }

    override fun onScoreUpdated(score: Int) {
        if (!isGameOver) {
            val isChinese = LanguageManager.getLanguage(this) == "zh"
            scoreTextView.text = if (isChinese) "得分: $score" else "Score: $score"
        }
    }

    override fun onGameOver(score: Int) {
        if (isGameOver) return

        Log.d(TAG, "游戏结束，分数: $score")
        isGameOver = true

        // 计算游戏时长
        val gameDuration = (System.currentTimeMillis() - gameStartTime) / 1000

        // 保存得分记录
        saveGameRecord(score, gameDuration)

        val isChinese = LanguageManager.getLanguage(this) == "zh"
        gameStatusTextView.text = if (isChinese) "游戏结束! 得分: $score" else "Game Over! Score: $score"
        gameController.stopGame()

        uiHandler.postDelayed({
            showGameOverDialog(score)
        }, 300)
    }

    private fun saveGameRecord(score: Int, duration: Long) {
        val playerName = scoreManager.getPlayerName()
        if (playerName.isNotBlank()) {
            val record = GameRecord(
                playerName = playerName,
                score = score,
                difficulty = currentDifficulty,
                date = Date(),
                gameDuration = duration
            )
            scoreManager.saveRecord(record)
            Log.d(TAG, "保存得分记录: $record")
        } else {
            Log.w(TAG, "玩家昵称为空，无法保存得分记录")
        }
    }

    private fun showGameOverDialog(score: Int) {
        if (gameOverDialog?.isShowing == true) {
            return
        }

        hideGameOverDialog()

        gameOverDialog = GameOverDialog(
            context = this,
            finalScore = score,
            onRestart = {
                restartGame()
            },
            onBackToMenu = {
                finish()
            }
        )

        gameOverDialog?.show()
    }

    private fun hideGameOverDialog() {
        gameOverDialog?.dismiss()
        gameOverDialog = null
    }

    override fun onDirectionChanged(direction: Direction) {
        if (!isGameOver) {
            gameController.setDirection(direction)
        }
    }

    override fun onGameRestart() {
        restartGame()
    }

    override fun onPause() {
        super.onPause()
        gameController.stopGame()
        hideGameOverDialog()
    }

    override fun onResume() {
        super.onResume()
        if (gameController.isGameRunning() && !isGameOver) {
            gameController.startGame()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        gameController.stopGame()
        hideGameOverDialog()
        uiHandler.removeCallbacksAndMessages(null)
    }
}