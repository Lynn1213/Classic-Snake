package com.example.snakegame.view

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Window
import android.widget.Button
import android.widget.TextView
import com.example.snakegame.R
import com.example.snakegame.utils.LanguageManager

class GameOverDialog(
    context: Context,
    private val finalScore: Int,
    private val onRestart: () -> Unit,
    private val onBackToMenu: () -> Unit
) : Dialog(context) {

    private lateinit var gameOverText: TextView
    private lateinit var scoreText: TextView
    private lateinit var restartButton: Button
    private lateinit var menuButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 设置无标题
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.dialog_game_over)

        // 设置对话框窗口属性
        setupWindowProperties()

        initViews()
        setupClickListeners()
        updateTexts()

        // 设置对话框不可取消
        setCancelable(false)
        setCanceledOnTouchOutside(false)
    }

    private fun setupWindowProperties() {
        window?.let { window ->
            // 设置透明背景
            window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

            // 移除窗口装饰
            window.decorView.setBackgroundColor(Color.TRANSPARENT)
        }
    }

    private fun initViews() {
        gameOverText = findViewById(R.id.gameOverText)
        scoreText = findViewById(R.id.scoreText)
        restartButton = findViewById(R.id.restartButton)
        menuButton = findViewById(R.id.menuButton)
    }

    private fun setupClickListeners() {
        restartButton.setOnClickListener {
            onRestart()
            dismiss()
        }

        menuButton.setOnClickListener {
            onBackToMenu()
            dismiss()
        }
    }

    private fun updateTexts() {
        val language = LanguageManager.getLanguage(context)
        val isChinese = language == "zh"

        gameOverText.text = context.getString(R.string.game_over)
        scoreText.text = if (isChinese) {
            "最终得分: $finalScore"
        } else {
            "Final Score: $finalScore"
        }
        restartButton.text = context.getString(R.string.restart_game)
        menuButton.text = context.getString(R.string.back_to_menu)
    }

    override fun show() {
        try {
            if (!isShowing && context != null) {
                super.show()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun dismiss() {
        try {
            if (isShowing) {
                super.dismiss()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}