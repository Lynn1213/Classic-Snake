package com.example.snakegame.utils

import android.content.Context
import android.content.SharedPreferences
import com.example.snakegame.model.Difficulty
import com.example.snakegame.model.GameRecord
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.*

class ScoreManager private constructor(context: Context) {

    companion object {
        private const val PREF_NAME = "snake_game_scores"
        private const val KEY_RECORDS = "game_records"
        private const val KEY_PLAYER_NAME = "player_name"
        private const val MAX_RECORDS = 20 // 最多保存20条记录

        @Volatile
        private var instance: ScoreManager? = null

        fun getInstance(context: Context): ScoreManager {
            return instance ?: synchronized(this) {
                instance ?: ScoreManager(context.applicationContext).also { instance = it }
            }
        }
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()

    fun saveRecord(record: GameRecord) {
        val records = getAllRecords().toMutableList()
        records.add(record)

        // 按分数排序并限制数量
        records.sort()
        val limitedRecords = if (records.size > MAX_RECORDS) {
            records.subList(0, MAX_RECORDS)
        } else {
            records
        }

        val json = gson.toJson(limitedRecords)
        prefs.edit().putString(KEY_RECORDS, json).apply()
    }

    fun getAllRecords(): List<GameRecord> {
        val json = prefs.getString(KEY_RECORDS, "[]") ?: "[]"
        val type = object : TypeToken<List<GameRecord>>() {}.type
        return gson.fromJson(json, type) ?: emptyList()
    }

    fun getRecordsByDifficulty(difficulty: Difficulty): List<GameRecord> {
        return getAllRecords().filter { it.difficulty == difficulty }
    }

    fun getTopScoreByDifficulty(difficulty: Difficulty): Int {
        return getRecordsByDifficulty(difficulty).maxByOrNull { it.score }?.score ?: 0
    }

    fun clearAllRecords() {
        prefs.edit().remove(KEY_RECORDS).apply()
    }

    fun savePlayerName(name: String) {
        prefs.edit().putString(KEY_PLAYER_NAME, name.trim()).apply()
    }

    fun getPlayerName(): String {
        return prefs.getString(KEY_PLAYER_NAME, "") ?: ""
    }
}