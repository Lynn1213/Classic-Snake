package com.example.snakegame.model

enum class Direction {
    UP, DOWN, LEFT, RIGHT
}

data class Point(val x: Int, val y: Int)

data class GameState(
    val snake: List<Point>,
    val food: Point,
    val score: Int,
    val isGameRunning: Boolean,
    val gridSize: Int = 20,
    val difficulty: Difficulty = Difficulty.NORMAL, // 添加难度字段
    val baseScore: Int = 10 // 添加基础得分字段
)