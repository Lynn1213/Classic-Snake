package com.example.snakegame.activity

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.snakegame.utils.LanguageManager
import java.util.Locale

open class BaseActivity : AppCompatActivity() {

    override fun attachBaseContext(newBase: Context) {
        val language = LanguageManager.getLanguage(newBase)
        super.attachBaseContext(updateContextLocale(newBase, language))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 确保配置正确
        LanguageManager.updateConfiguration(this, LanguageManager.getLanguage(this))
    }

    // 更新上下文区域设置
    private fun updateContextLocale(context: Context, language: String): Context {
        val locale = Locale(language)
        Locale.setDefault(locale)

        return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            val configuration = context.resources.configuration
            configuration.setLocale(locale)
            context.createConfigurationContext(configuration)
        } else {
            context
        }
    }

    // 安全切换语言，不重建Activity
    protected fun safeChangeLanguage(language: String) {
        if (LanguageManager.needsLanguageUpdate(this, language)) {
            LanguageManager.setLanguage(this, language)
            LanguageManager.updateConfiguration(this, language)
            updateUIWithCurrentLanguage()
        }
    }

    // 正确的onConfigurationChanged方法签名
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // 当配置改变时（如语言切换），更新UI
        updateUIWithCurrentLanguage()
    }

    // 子类需要重写此方法来更新UI
    protected open fun updateUIWithCurrentLanguage() {
        // 默认实现为空，子类需要重写
    }
}