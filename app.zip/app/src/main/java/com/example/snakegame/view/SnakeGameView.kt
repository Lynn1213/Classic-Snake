package com.example.snakegame.view

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.util.Log
import android.view.View
import com.example.snakegame.model.GameState

class SnakeGameView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var cellSize = 0
    private var gridWidth = 0
    private var gridHeight = 0

    // 颜色定义 - 使用更鲜艳的颜色
    private val snakeColor = Color.parseColor("#4CAF50") // 绿色
    private val foodColor = Color.parseColor("#FF5722")  // 橙色
    private val gridColor = Color.parseColor("#424242")  // 深灰色
    private val snakeHeadColor = Color.parseColor("#FFEB3B") // 黄色
    private val backgroundColor = Color.BLACK

    private val paint = Paint()
    private var gameState: GameState? = null

    var gameCallback: GameCallback? = null

    companion object {
        private const val TAG = "SnakeGameView"
    }

    init {
        Log.d(TAG, "SnakeGameView初始化")
        paint.isAntiAlias = true
        paint.style = Paint.Style.FILL
    }

    fun updateGameState(newGameState: GameState) {
        Log.d(TAG, "更新游戏状态: 蛇长度=${newGameState.snake.size}, 食物位置=(${newGameState.food.x},${newGameState.food.y})")
        gameState = newGameState
        invalidate() // 请求重绘
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        val width = MeasureSpec.getSize(widthMeasureSpec)
        val height = MeasureSpec.getSize(heightMeasureSpec)
        Log.d(TAG, "onMeasure: 宽度=$width, 高度=$height")
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        Log.d(TAG, "onSizeChanged: 宽度=$w, 高度=$h")

        // 使用默认网格大小计算，不依赖 gameState
        val defaultGridSize = 20
        cellSize = (w.coerceAtMost(h) - 2) / defaultGridSize
        gridWidth = cellSize * defaultGridSize
        gridHeight = cellSize * defaultGridSize

        Log.d(TAG, "计算尺寸: cellSize=$cellSize, gridWidth=$gridWidth, gridHeight=$gridHeight")
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        Log.d(TAG, "onDraw 被调用")

        try {
            // 绘制黑色背景
            canvas.drawColor(backgroundColor)
            Log.d(TAG, "✓ 背景绘制完成")

            gameState?.let { state ->
                Log.d(TAG, "开始绘制游戏状态: 蛇=${state.snake.size}节, 食物=(${state.food.x},${state.food.y})")

                // 绘制网格背景
                drawGrid(canvas, state.gridSize)
                Log.d(TAG, "✓ 网格绘制完成")

                // 绘制食物
                paint.color = foodColor
                val foodRect = RectF(
                    state.food.x * cellSize.toFloat(),
                    state.food.y * cellSize.toFloat(),
                    (state.food.x + 1) * cellSize.toFloat(),
                    (state.food.y + 1) * cellSize.toFloat()
                )
                canvas.drawRect(foodRect, paint)
                Log.d(TAG, "✓ 食物绘制在: (${state.food.x}, ${state.food.y}) -> [$foodRect]")

                // 绘制蛇身
                paint.color = snakeColor
                for ((index, segment) in state.snake.withIndex()) {
                    val segmentRect = RectF(
                        segment.x * cellSize.toFloat(),
                        segment.y * cellSize.toFloat(),
                        (segment.x + 1) * cellSize.toFloat(),
                        (segment.y + 1) * cellSize.toFloat()
                    )
                    canvas.drawRect(segmentRect, paint)
                    if (index == 0) {
                        Log.d(TAG, "蛇头位置: (${segment.x}, ${segment.y}) -> [$segmentRect]")
                    }
                }
                Log.d(TAG, "✓ 蛇身绘制完成，共${state.snake.size}节")

                // 绘制蛇头（不同颜色）
                if (state.snake.isNotEmpty()) {
                    paint.color = snakeHeadColor
                    val head = state.snake.first()
                    val headRect = RectF(
                        head.x * cellSize.toFloat(),
                        head.y * cellSize.toFloat(),
                        (head.x + 1) * cellSize.toFloat(),
                        (head.y + 1) * cellSize.toFloat()
                    )
                    canvas.drawRect(headRect, paint)
                    Log.d(TAG, "✓ 蛇头高亮绘制完成")
                }

                Log.d(TAG, "✓ 所有游戏元素绘制完成")

            } ?: run {
                // 如果gameState为null，绘制空网格和提示信息
                Log.w(TAG, "gameState为null，绘制空网格")
                drawGrid(canvas, 20)

                // 绘制提示文本
                paint.color = Color.WHITE
                paint.textSize = 48f
                paint.textAlign = Paint.Align.CENTER
                canvas.drawText("等待游戏开始...", width / 2f, height / 2f, paint)
            }

            Log.d(TAG, "✓ onDraw 执行成功")

        } catch (e: Exception) {
            Log.e(TAG, "!!! onDraw 执行失败 !!!", e)

            // 绘制错误信息
            paint.color = Color.RED
            paint.textSize = 24f
            canvas.drawText("绘制错误: ${e.message}", 50f, 50f, paint)
        }
    }

    private fun drawGrid(canvas: Canvas, gridSize: Int) {
        try {
            paint.color = gridColor
            paint.strokeWidth = 1f

            // 绘制垂直线
            for (i in 0..gridSize) {
                val x = i * cellSize.toFloat()
                canvas.drawLine(x, 0f, x, gridHeight.toFloat(), paint)
            }

            // 绘制水平线
            for (i in 0..gridSize) {
                val y = i * cellSize.toFloat()
                canvas.drawLine(0f, y, gridWidth.toFloat(), y, paint)
            }

            Log.d(TAG, "网格绘制: $gridSize x $gridSize, cellSize=$cellSize")

        } catch (e: Exception) {
            Log.e(TAG, "drawGrid失败", e)
        }
    }
}