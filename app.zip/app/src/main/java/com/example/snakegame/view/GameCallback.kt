package com.example.snakegame.view

import com.example.snakegame.model.Direction

interface GameCallback {
    fun onScoreUpdated(score: Int)
    fun onGameOver(score: Int)
    fun onDirectionChanged(direction: Direction)
    fun onGameRestart()
}