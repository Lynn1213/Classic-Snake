package com.example.snakegame.activity

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import com.example.snakegame.R
import com.example.snakegame.SnakeGameApplication
import com.example.snakegame.model.Difficulty
import com.example.snakegame.utils.GameDifficultyManager
import com.example.snakegame.utils.LanguageManager
import com.example.snakegame.utils.ScoreManager

class MainMenuActivity : BaseActivity() {

    private lateinit var titleText: TextView
    private lateinit var playerNameLabel: TextView
    private lateinit var playerNameInput: EditText
    private lateinit var startGameButton: Button
    private lateinit var scoreHistoryButton: Button
    private lateinit var exitButton: Button
    private lateinit var languageRadioGroup: RadioGroup
    private lateinit var englishRadio: RadioButton
    private lateinit var chineseRadio: RadioButton
    private lateinit var difficultyRadioGroup: RadioGroup
    private lateinit var easyRadio: RadioButton
    private lateinit var normalRadio: RadioButton
    private lateinit var hardRadio: RadioButton
    private lateinit var currentDifficultyText: TextView
    private lateinit var highScoreText: TextView

    private val scoreManager by lazy { ScoreManager.getInstance(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_menu)

        initViews()
        setupClickListeners()
        loadPlayerName()
        updateLanguageSelection()
        updateDifficultySelection()
        updateUIWithCurrentLanguage()
        updateHighScoreDisplay()
    }

    private fun initViews() {
        titleText = findViewById(R.id.titleText)
        playerNameLabel = findViewById(R.id.playerNameLabel)
        playerNameInput = findViewById(R.id.playerNameInput)
        startGameButton = findViewById(R.id.startGameButton)
        scoreHistoryButton = findViewById(R.id.scoreHistoryButton)
        exitButton = findViewById(R.id.exitButton)
        languageRadioGroup = findViewById(R.id.languageRadioGroup)
        englishRadio = findViewById(R.id.englishRadio)
        chineseRadio = findViewById(R.id.chineseRadio)
        difficultyRadioGroup = findViewById(R.id.difficultyRadioGroup)
        easyRadio = findViewById(R.id.easyRadio)
        normalRadio = findViewById(R.id.normalRadio)
        hardRadio = findViewById(R.id.hardRadio)
        currentDifficultyText = findViewById(R.id.currentDifficultyText)
        highScoreText = findViewById(R.id.highScoreText)
    }

    private fun loadPlayerName() {
        val savedName = scoreManager.getPlayerName()
        if (savedName.isNotBlank()) {
            playerNameInput.setText(savedName)
        }
    }

    private fun setupClickListeners() {
        startGameButton.setOnClickListener {
            if (validatePlayerName()) {
                val intent = Intent(this, GameActivity::class.java)
                startActivity(intent)
            }
        }

        scoreHistoryButton.setOnClickListener {
            if (validatePlayerName()) {
                val intent = Intent(this, ScoreHistoryActivity::class.java)
                startActivity(intent)
            }
        }

        exitButton.setOnClickListener {
            finishAffinity()
        }

        languageRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.englishRadio -> setAppLanguage("en")
                R.id.chineseRadio -> setAppLanguage("zh")
            }
        }

        difficultyRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.easyRadio -> setDifficulty(Difficulty.EASY)
                R.id.normalRadio -> setDifficulty(Difficulty.NORMAL)
                R.id.hardRadio -> setDifficulty(Difficulty.HARD)
            }
        }

        // 保存玩家姓名
        playerNameInput.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                savePlayerName()
            }
        }
    }

    private fun validatePlayerName(): Boolean {
        val name = playerNameInput.text.toString().trim()
        if (name.isEmpty()) {
            showAlertDialog(
                if (LanguageManager.getLanguage(this) == "zh") "提示" else "Notice",
                if (LanguageManager.getLanguage(this) == "zh") "请输入您的昵称" else "Please enter your nickname"
            )
            return false
        }
        savePlayerName()
        return true
    }

    private fun showAlertDialog(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun savePlayerName() {
        val name = playerNameInput.text.toString().trim()
        if (name.isNotBlank()) {
            scoreManager.savePlayerName(name)
        }
    }

    private fun setDifficulty(difficulty: Difficulty) {
        GameDifficultyManager.saveDifficulty(this, difficulty)
        updateHighScoreDisplay()
        updateCurrentDifficultyText()
    }

    private fun updateLanguageSelection() {
        val currentLang = LanguageManager.getLanguage(this)

        // 临时移除监听器避免触发
        languageRadioGroup.setOnCheckedChangeListener(null)
        difficultyRadioGroup.setOnCheckedChangeListener(null)

        when (currentLang) {
            "zh" -> chineseRadio.isChecked = true
            else -> englishRadio.isChecked = true
        }

        // 设置难度选择
        val currentDifficulty = GameDifficultyManager.getDifficulty(this)
        when (currentDifficulty) {
            Difficulty.EASY -> easyRadio.isChecked = true
            Difficulty.NORMAL -> normalRadio.isChecked = true
            Difficulty.HARD -> hardRadio.isChecked = true
        }

        // 重新设置监听器
        languageRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.englishRadio -> setAppLanguage("en")
                R.id.chineseRadio -> setAppLanguage("zh")
            }
        }

        difficultyRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.easyRadio -> setDifficulty(Difficulty.EASY)
                R.id.normalRadio -> setDifficulty(Difficulty.NORMAL)
                R.id.hardRadio -> setDifficulty(Difficulty.HARD)
            }
        }
    }

    private fun updateDifficultySelection() {
        val currentDifficulty = GameDifficultyManager.getDifficulty(this)
        when (currentDifficulty) {
            Difficulty.EASY -> easyRadio.isChecked = true
            Difficulty.NORMAL -> normalRadio.isChecked = true
            Difficulty.HARD -> hardRadio.isChecked = true
        }
        updateCurrentDifficultyText()
    }

    private fun updateCurrentDifficultyText() {
        val isChinese = LanguageManager.getLanguage(this) == "zh"
        val currentDifficulty = GameDifficultyManager.getDifficulty(this)
        val difficultyName = currentDifficulty.getDisplayName(isChinese)
        val scorePerFood = currentDifficulty.baseScore

        currentDifficultyText.text = if (isChinese) {
            "当前难度: $difficultyName (每个食物: ${scorePerFood}分)"
        } else {
            "Current: $difficultyName (${scorePerFood}pts/food)"
        }
    }

    private fun updateHighScoreDisplay() {
        val isChinese = LanguageManager.getLanguage(this) == "zh"
        val currentDifficulty = GameDifficultyManager.getDifficulty(this)
        val highScore = scoreManager.getTopScoreByDifficulty(currentDifficulty)

        highScoreText.text = if (isChinese) {
            "${currentDifficulty.getDisplayName(true)}最高分: $highScore"
        } else {
            "${currentDifficulty.getDisplayName(false)} High Score: $highScore"
        }
    }

    private fun setAppLanguage(language: String) {
        (application as SnakeGameApplication).updateLanguage(language)
        recreate()
    }

    override fun updateUIWithCurrentLanguage() {
        val isChinese = LanguageManager.getLanguage(this) == "zh"

        titleText.text = getString(R.string.app_name)
        playerNameLabel.text = if (isChinese) "玩家昵称:" else "Player Name:"
        playerNameInput.hint = if (isChinese) "输入您的名字" else "Enter your name"
        startGameButton.text = if (isChinese) "开始游戏" else "Start Game"
        scoreHistoryButton.text = if (isChinese) "历史得分" else "Score History"
        exitButton.text = if (isChinese) "退出游戏" else "Exit Game"
        englishRadio.text = if (isChinese) "英文" else "English"
        chineseRadio.text = if (isChinese) "中文" else "Chinese"
        easyRadio.text = Difficulty.EASY.getDisplayName(isChinese)
        normalRadio.text = Difficulty.NORMAL.getDisplayName(isChinese)
        hardRadio.text = Difficulty.HARD.getDisplayName(isChinese)

        updateCurrentDifficultyText()
        updateHighScoreDisplay()
    }
}