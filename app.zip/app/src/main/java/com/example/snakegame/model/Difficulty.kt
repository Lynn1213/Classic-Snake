package com.example.snakegame.model

enum class Difficulty(
    val id: Int,
    val defaultName: String,
    val chineseName: String,
    val speed: Long, // 移动间隔（毫秒），值越大越慢
    val baseScore: Int, // 基础得分
    val foodSpawnRate: Int // 食物生成率（1-10，越高越容易）
) {
    EASY(1, "Easy", "简单", 300L, 10, 8),
    NORMAL(2, "Normal", "普通", 200L, 20, 6),
    HARD(3, "Hard", "困难", 100L, 30, 4);

    fun getDisplayName(isChinese: Boolean = false): String {
        return if (isChinese) chineseName else defaultName
    }

    companion object {
        fun fromId(id: Int): Difficulty {
            return values().find { it.id == id } ?: NORMAL
        }
    }
}