package com.example.snakegame.activity

import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.snakegame.R
import com.example.snakegame.adapter.ScoreHistoryAdapter
import com.example.snakegame.model.Difficulty
import com.example.snakegame.utils.LanguageManager
import com.example.snakegame.utils.ScoreManager

class ScoreHistoryActivity : AppCompatActivity() {

    private lateinit var titleText: TextView
    private lateinit var backButton: Button
    private lateinit var clearButton: Button
    private lateinit var recyclerView: RecyclerView
    private lateinit var difficultyRadioGroup: RadioGroup
    private lateinit var allRadio: RadioButton
    private lateinit var easyRadio: RadioButton
    private lateinit var normalRadio: RadioButton
    private lateinit var hardRadio: RadioButton
    private lateinit var emptyText: TextView

    private lateinit var adapter: ScoreHistoryAdapter
    private val scoreManager by lazy { ScoreManager.getInstance(this) }
    private var currentFilter: Difficulty? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_score_history)

        initViews()
        setupRecyclerView()
        setupClickListeners()
        updateLanguageSelection()
        loadScoreHistory()
        updateUIWithCurrentLanguage()
    }

    private fun initViews() {
        titleText = findViewById(R.id.titleText)
        backButton = findViewById(R.id.backButton)
        clearButton = findViewById(R.id.clearButton)
        recyclerView = findViewById(R.id.recyclerView)
        difficultyRadioGroup = findViewById(R.id.difficultyRadioGroup)
        allRadio = findViewById(R.id.allRadio)
        easyRadio = findViewById(R.id.easyRadio)
        normalRadio = findViewById(R.id.normalRadio)
        hardRadio = findViewById(R.id.hardRadio)
        emptyText = findViewById(R.id.emptyText)
    }

    private fun setupRecyclerView() {
        val isChinese = LanguageManager.getLanguage(this) == "zh"
        adapter = ScoreHistoryAdapter(isChinese = isChinese)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    private fun setupClickListeners() {
        backButton.setOnClickListener {
            finish()
        }

        clearButton.setOnClickListener {
            scoreManager.clearAllRecords()
            loadScoreHistory()
        }

        difficultyRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            currentFilter = when (checkedId) {
                R.id.easyRadio -> Difficulty.EASY
                R.id.normalRadio -> Difficulty.NORMAL
                R.id.hardRadio -> Difficulty.HARD
                else -> null
            }
            loadScoreHistory()
        }
    }

    private fun updateLanguageSelection() {
        difficultyRadioGroup.setOnCheckedChangeListener(null)
        allRadio.isChecked = true
        currentFilter = null
        difficultyRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            currentFilter = when (checkedId) {
                R.id.easyRadio -> Difficulty.EASY
                R.id.normalRadio -> Difficulty.NORMAL
                R.id.hardRadio -> Difficulty.HARD
                else -> null
            }
            loadScoreHistory()
        }
    }

    private fun loadScoreHistory() {
        val records = if (currentFilter == null) {
            scoreManager.getAllRecords()
        } else {
            scoreManager.getRecordsByDifficulty(currentFilter!!)
        }

        val isChinese = LanguageManager.getLanguage(this) == "zh"
        adapter = ScoreHistoryAdapter(records, isChinese)
        recyclerView.adapter = adapter

        if (records.isEmpty()) {
            emptyText.visibility = TextView.VISIBLE
            recyclerView.visibility = RecyclerView.GONE
        } else {
            emptyText.visibility = TextView.GONE
            recyclerView.visibility = RecyclerView.VISIBLE
        }
    }

    private fun updateUIWithCurrentLanguage() {
        val isChinese = LanguageManager.getLanguage(this) == "zh"

        titleText.text = if (isChinese) "历史得分" else "Score History"
        backButton.text = if (isChinese) "返回" else "Back"
        clearButton.text = if (isChinese) "清空记录" else "Clear All"

        allRadio.text = if (isChinese) "全部" else "All"
        easyRadio.text = Difficulty.EASY.getDisplayName(isChinese)
        normalRadio.text = Difficulty.NORMAL.getDisplayName(isChinese)
        hardRadio.text = Difficulty.HARD.getDisplayName(isChinese)
        emptyText.text = if (isChinese) "暂无得分记录" else "No score records yet"
    }
}