package com.example.snakegame.model

import android.util.Log
import kotlin.random.Random

class Snake {
    private var _body: MutableList<Point> = mutableListOf()
    private var _direction: Direction = Direction.RIGHT
    private var _food: Point = Point(0, 0)
    private var _score: Int = 0
    private var _baseScore: Int = 10 // 基础得分
    private var _isGameRunning: Boolean = true
    private val _gridSize: Int = 20
    private var _difficulty: Difficulty = Difficulty.NORMAL
    private var _foodSpawnAttempts: Int = 0
    private var _maxFoodSpawnAttempts: Int = 100

    companion object {
        private const val TAG = "Snake"
    }

    fun setDifficulty(difficulty: Difficulty) {
        _difficulty = difficulty
        _baseScore = difficulty.baseScore
        // 根据难度调整食物生成尝试次数
        _maxFoodSpawnAttempts = when (difficulty) {
            Difficulty.EASY -> 50  // 简单模式容易生成食物
            Difficulty.NORMAL -> 100 // 普通模式
            Difficulty.HARD -> 200  // 困难模式更难生成食物
        }
        Log.d(TAG, "设置难度: ${difficulty.getDisplayName()}, 基础得分: $_baseScore")
    }

    val gameState: GameState
        get() = GameState(
            snake = _body.toList(),
            food = _food,
            score = _score,
            isGameRunning = _isGameRunning,
            gridSize = _gridSize,
            difficulty = _difficulty,
            baseScore = _baseScore
        )

    fun initialize() {
        Log.d(TAG, "初始化蛇身")
        _body.clear()
        // 初始化蛇，长度为3
        _body.add(Point(5, 10))
        _body.add(Point(4, 10))
        _body.add(Point(3, 10))

        _direction = Direction.RIGHT
        _score = 0
        _isGameRunning = true
        _foodSpawnAttempts = 0
        generateFood()

        Log.d(TAG, "蛇身初始化完成，长度: ${_body.size}, 难度: ${_difficulty.getDisplayName()}")
    }

    fun setDirection(newDirection: Direction) {
        // 防止直接反向移动
        if ((_direction == Direction.UP && newDirection == Direction.DOWN) ||
            (_direction == Direction.DOWN && newDirection == Direction.UP) ||
            (_direction == Direction.LEFT && newDirection == Direction.RIGHT) ||
            (_direction == Direction.RIGHT && newDirection == Direction.LEFT)) {
            return
        }
        _direction = newDirection
    }

    fun update() {
        if (!_isGameRunning) return

        // 安全检查：确保蛇身不为空
        if (_body.isEmpty()) {
            Log.e(TAG, "错误：蛇身列表为空！")
            _isGameRunning = false
            return
        }

        // 移动蛇
        val head = _body.first()
        val newHead = when (_direction) {
            Direction.UP -> Point(head.x, head.y - 1)
            Direction.DOWN -> Point(head.x, head.y + 1)
            Direction.LEFT -> Point(head.x - 1, head.y)
            Direction.RIGHT -> Point(head.x + 1, head.y)
        }

        Log.d(TAG, "蛇移动: 从(${head.x},${head.y}) 到 (${newHead.x},${newHead.y})")

        // 检查碰撞
        if (newHead.x < 0 || newHead.x >= _gridSize ||
            newHead.y < 0 || newHead.y >= _gridSize ||
            _body.contains(newHead)) {
            Log.d(TAG, "碰撞检测：游戏结束")
            _isGameRunning = false
            return
        }

        _body.add(0, newHead)

        // 检查是否吃到食物
        if (newHead == _food) {
            _score += _baseScore
            Log.d(TAG, "吃到食物！新分数: $_score (基础分: $_baseScore)")
            _foodSpawnAttempts = 0
            generateFood()
        } else {
            _body.removeAt(_body.size - 1)
        }

        Log.d(TAG, "蛇身长度: ${_body.size}, 分数: $_score")
    }

    private fun generateFood() {
        var newFood: Point
        var attempts = 0
        val maxAttempts = _maxFoodSpawnAttempts

        do {
            // 根据难度调整生成逻辑
            when (_difficulty) {
                Difficulty.EASY -> {
                    // 简单模式：随机位置
                    newFood = Point(
                        Random.nextInt(0, _gridSize),
                        Random.nextInt(0, _gridSize)
                    )
                }
                Difficulty.NORMAL -> {
                    // 普通模式：随机位置
                    newFood = Point(
                        Random.nextInt(0, _gridSize),
                        Random.nextInt(0, _gridSize)
                    )
                }
                Difficulty.HARD -> {
                    // 困难模式：可能靠近蛇身或边界
                    val nearBoundary = Random.nextBoolean()
                    if (nearBoundary && _body.isNotEmpty()) {
                        val head = _body.first()
                        val offsetX = Random.nextInt(-2, 3)
                        val offsetY = Random.nextInt(-2, 3)
                        newFood = Point(
                            (head.x + offsetX).coerceIn(0, _gridSize - 1),
                            (head.y + offsetY).coerceIn(0, _gridSize - 1)
                        )
                    } else {
                        newFood = Point(
                            Random.nextInt(0, _gridSize),
                            Random.nextInt(0, _gridSize)
                        )
                    }
                }
            }
            attempts++
        } while (_body.contains(newFood) && attempts < maxAttempts)

        if (attempts >= maxAttempts) {
            Log.e(TAG, "生成食物失败：尝试次数过多")
            // 如果无法找到合适位置，使用默认位置
            newFood = Point(10, 10)
        }

        _food = newFood
        _foodSpawnAttempts = attempts
        Log.d(TAG, "生成食物在位置: (${_food.x}, ${_food.y}), 尝试次数: $attempts")
    }

    fun isGameRunning(): Boolean = _isGameRunning

    fun getCurrentScore(): Int = _score

    fun getCurrentDifficulty(): Difficulty = _difficulty
}